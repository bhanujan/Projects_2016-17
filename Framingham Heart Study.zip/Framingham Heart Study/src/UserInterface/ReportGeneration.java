/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterface;
import java.util.Scanner;
import Patient.Patient;
/**
 *
 * @author Bhanuja Nagore
 */
public class ReportGeneration {
    private static Scanner scanner = new Scanner(System.in);
    private static Patient patient = new Patient();
    private static int option;
    
    
  
}
