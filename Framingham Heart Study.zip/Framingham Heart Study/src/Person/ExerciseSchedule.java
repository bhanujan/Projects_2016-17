/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Person;

/**
 *
 * @author Bhanuja Nagore
 */

public class ExerciseSchedule {
    private float joggingHrsPerDay;
    private int caloriesConsumedForJogging;
    private float swimmingHrsPerDay;
    private int caloriesConsumedForSwimming;

    public float getJoggingHrsPerDay() {
        return joggingHrsPerDay;
    }

    public void setJoggingHrsPerDay(float joggingHrsPerDay) {
        this.joggingHrsPerDay = joggingHrsPerDay;
    }

    public int getCaloriesConsumedForJogging() {
        return caloriesConsumedForJogging;
    }

    public void setCaloriesConsumedForJogging(int caloriesConsumedForJogging) {
        this.caloriesConsumedForJogging = caloriesConsumedForJogging;
    }

    public float getSwimmingHrsPerDay() {
        return swimmingHrsPerDay;
    }

    public void setSwimmingHrsPerDay(float swimmingHrsPerDay) {
        this.swimmingHrsPerDay = swimmingHrsPerDay;
    }

    public int getCaloriesConsumedForSwimming() {
        return caloriesConsumedForSwimming;
    }

    public void setCaloriesConsumedForSwimming(int caloriesConsumedForSwimming) {
        this.caloriesConsumedForSwimming = caloriesConsumedForSwimming;
    }
    
    
}
