/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Department;

import Business.Employee.EmployeeDirectory;
import Business.Refugee.RefugeeAllocationWorkQueue;
import Business.Refugee.RefugeeDirectory;
import Business.Role.Role;
import Business.UserAccount.UserAccountDirectory;
import Business.VitalSigns.VitalSignsHistory;
import Business.WorkQueue.WorkQueue;
import java.util.ArrayList;

/**
 *
 * @author Rohan Jahagirdar, Bhanuja Nagore, Manish Patil
 */
public abstract class Department {

    private String name;
    private RefugeeAllocationWorkQueue workQueue;
    private EmployeeDirectory employeeDirectory;
    private UserAccountDirectory userAccountDirectory;
    private VitalSignsHistory vitalSignsHistory;
    private int departmentID;
    private static int counter;
    
    private static RefugeeAllocationWorkQueue refugeeAllocationWorkQueue;
    
    public enum Type{
        Admin("Admin Department"), 
        Country("Country Department"), 
        HealthcareDeptHead("Healthcare Department"), 
        EducationDepartmentHead("Education Department"),
        EmploymentDepartmentHead("Employment Department"),
        Cabinet("Cabinet Department"),
        HRDepartmentHead("HR Department"),
        Doctor("Doctor Department");
        
        private String value;
        private Type(String value) {
            this.value = value;
        }
        public String getValue() {
            return value;
        }
    }

    public Department(String name) {
        this.name = name;
        employeeDirectory = new EmployeeDirectory();
        userAccountDirectory = new UserAccountDirectory();
        refugeeAllocationWorkQueue = new RefugeeAllocationWorkQueue();
        vitalSignsHistory = new VitalSignsHistory();
        departmentID = counter;
        ++counter;
    }

    public abstract ArrayList<Role> getSupportedRole();
    
    public UserAccountDirectory getUserAccountDirectory() {
        return userAccountDirectory;
    }

    public int getDepartmentID() {
        return departmentID;
    }

    public VitalSignsHistory getVitalSignsHistory() {
        return vitalSignsHistory;
    }

    public EmployeeDirectory getEmployeeDirectory() {
        return employeeDirectory;
    }
    
    public String getName() {
        return name;
    }
    
    /*
    public RefugeeDirectory getRefugeeDirectory() {
        return refugeeDirectory;
    }
   */
    public void setName(String name) {
        this.name = name;
    }
    

    public static RefugeeAllocationWorkQueue getRefugeeAllocationWorkQueue() {
        return refugeeAllocationWorkQueue;
    }
    

    @Override
    public String toString() {
        return name;
    }
    
    
}
