/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

import Business.UnitedNations.UnitedNations;
import Business.Country.Country;
import Business.Department.Department;
import Business.UserAccount.UserAccount;
import javax.swing.JPanel;
import userinterface.SystemAdminWorkArea.SystemAdminWorkAreaJPanel;


/**
 *
 * @author Rohan Jahagirdar, Bhanuja Nagore, Manish Patil
 */
public class SystemAdminRole extends Role{

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Department department, Country country, UnitedNations system) {
        return new SystemAdminWorkAreaJPanel(userProcessContainer, system);
    }
    
}
