/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Refugee;

import Business.Citizen.Citizen;
import Business.Citizen.CitizenDirectory;
import Business.Country.Country;
import Business.UserAccount.UserAccount;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Rohan Jahagirdar, Bhanuja Nagore, Manish Patil
 */
public class RefugeeAllocationWorkQueue {
    private ArrayList<RefugeeWorkRequest> workRequestList;

    public RefugeeAllocationWorkQueue() {
        workRequestList = new ArrayList<>();
    }

    public ArrayList<RefugeeWorkRequest> getRefugeeAllocationWorkQueue() {
        return workRequestList;
    }
    
    public void reportCitizensAvailibility(UserAccount countryHeadAccount, CitizenDirectory citizens) {
        RefugeeWorkRequest refugeeWorkRequest = new RefugeeWorkRequest();
        refugeeWorkRequest.setSender(countryHeadAccount);
        refugeeWorkRequest.setReceiver(null);
        refugeeWorkRequest.setStatus("Pending");
        refugeeWorkRequest.setCitizenDirectory(citizens);
        workRequestList.add(refugeeWorkRequest);
    }
    
    public void requestAllocation(UserAccount receiverCountryUserAccount, 
            RefugeeWorkRequest refugeeWorkRequest) {
        refugeeWorkRequest.setReceiver(receiverCountryUserAccount);
        //refugeeWorkRequest.setStatus("Pending");
        refugeeWorkRequest.setRequestDate(new Date());
    }
    
    
    public void createRefugeeRequest(RefugeeWorkRequest refugeeWorkRequest) {
        //workRequestList.get
        refugeeWorkRequest.setStatus("Pending");
        workRequestList.add(refugeeWorkRequest);
        
    }
    
    public void changePendingToAcknowledged(RefugeeWorkRequest refugeeWorkRequest) {
        refugeeWorkRequest.setStatus("Acknowledged");
    }

    public void changeAcknowledgedToProcessing(RefugeeWorkRequest refugeeWorkRequest) {
        refugeeWorkRequest.setStatus("Processing");
    }
    
    public void changeProcessingToCompleted(RefugeeWorkRequest refugeeWorkRequest) {
        refugeeWorkRequest.setStatus("Completed");
    }
}
