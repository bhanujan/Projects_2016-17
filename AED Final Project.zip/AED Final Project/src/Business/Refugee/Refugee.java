/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Refugee;



import Business.Education.Education;
import Business.Finance.Finance;
import Business.Passport.Passport;
import Business.VitalSigns.VitalSignsHistory;
import Business.Citizen.Citizen;
import Business.Country.Country;
import Business.Person.Gender;
import Business.Person.Person;

import java.util.Date;
import javax.swing.ImageIcon;

/**
 *
 * @author Rohan Jahagirdar, Bhanuja Nagore, Manish Patil
 */
public class Refugee extends Person{
    private int id;
    private Finance finance;
    private Education education;
    private Citizen citizenship;
    
    private String firstName;
    private String lastName;
    private String dateOfBirth;
    private String address1;
    private String address2;
    private VitalSignsHistory vitalSignsHistory;
    private Passport passport;
    private Gender gender;
    private String countryOfBirth;
    private String dateOfReport;
    private String currentCityOfStay;
    private ImageIcon image;
    private String NUID;
    private String educationQual;
    private String colName;
    private String startDateEdu;
    private String endDateEdu;
    private String degreeName;
    private String entryDate;
    private float riskScore;
    private int age;
    
    private int colorTestScore;
   
    
    
    private static int count = 1;

    public Refugee() {
        id = count;
        count++;
        vitalSignsHistory = new VitalSignsHistory();
        colorTestScore = 0;
        education = new Education();
    }

    public int getId() {
        return id;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Education getEducation() {
        return education;
    }

    public float getRiskScore() {
        return riskScore;
    }

    public void setRiskScore(float riskScore) {
        this.riskScore = riskScore;
    }

    public void setEducation(Education education) {
        this.education = education;
    }
    
    public Citizen getCitizenship() {
        return citizenship;
    }

    public void setCitizenship(Citizen citizenship) {
        this.citizenship = citizenship;
    }
    @Override
    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

  


    public String getNUID() {
        return NUID;
    }

    public void setNUID(String NUID) {
        this.NUID = NUID;
    }

    public String getEducationQual() {
        return educationQual;
    }

    public void setEducationQual(String educationQual) {
        this.educationQual = educationQual;
    }

    public String getColName() {
        return colName;
    }

    public void setColName(String colName) {
        this.colName = colName;
    }

    public String getDegreeName() {
        return degreeName;
    }

    public void setDegreeName(String degreeName) {
        this.degreeName = degreeName;
    }
    
    @Override
    public String getFirstName() {
        return firstName;
    }

    @Override
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @Override
    public String getLastName() {
        return lastName;
    }

    @Override
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }


    @Override
    public String getAddress1() {
        return address1;
    }

    @Override
    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    @Override
    public String getAddress2() {
        return address2;
    }

    @Override
    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    
    public VitalSignsHistory getVitalSignsHistory() {
        return vitalSignsHistory;
    }

    
    public void setVitalSignsHistory(VitalSignsHistory vitalSignsHistory) {
        this.vitalSignsHistory = vitalSignsHistory;
    }

    @Override
    public Passport getPassport() {
        return passport;
    }

    @Override
    public void setPassport(Passport passport) {
        this.passport = passport;
    }

    @Override
    public Gender getGender() {
        return gender;
    }

    @Override
    public void setGender(Gender gender) {
        this.gender = gender;
    }
    
    @Override
    public String getCountryOfBirth() {
        return countryOfBirth;
    }
    
    @Override
    public void setCountryOfBirth(String countryOfBirth){
        this.countryOfBirth = countryOfBirth;
    }
    
    @Override
    public String getNames() {
        return firstName + lastName;
    }
    
    public String getCurrentCityOfStay() {
        return currentCityOfStay;
    }

    public void setCurrentCityOfStay(String currentCityOfStay) {
        this.currentCityOfStay = currentCityOfStay;
    }

    public ImageIcon getImage() {
        return image;
    }

    public void setImage(ImageIcon image) {
        this.image = image;
    }

    public Finance getFinance() {
        return finance;
    }

    public void setFinance(Finance finance) {
        this.finance = finance;
    }
    
    @Override
    public String getDateOfBirth() {
        return dateOfBirth;
    }


    public String getDateOfReport() {
        return dateOfReport;
    }

    public void setDateOfReport(String dateOfReport) {
        this.dateOfReport = dateOfReport;
    }

    public String getStartDateEdu() {
        return startDateEdu;
    }

    public void setStartDateEdu(String startDateEdu) {
        this.startDateEdu = startDateEdu;
    }

    public String getEndDateEdu() {
        return endDateEdu;
    }

    public void setEndDateEdu(String endDateEdu) {
        this.endDateEdu = endDateEdu;
    }

    public String getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(String entryDate) {
        this.entryDate = entryDate;
    }

    public int getColorTestScore() {
        return colorTestScore;
    }

    public void setColorTestScore(int colorTestScore) {
        this.colorTestScore = colorTestScore;
    }
    
    
}
