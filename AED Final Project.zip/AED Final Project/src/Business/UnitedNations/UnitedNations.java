package Business.UnitedNations;

import Business.Continent.Continent;
import Business.ContinentDirectory;
import Business.Department.Department;
import Business.Employee.Employee;
import Business.Employee.EmployeeDirectory;
import Business.Refugee.Refugee;
import Business.Refugee.RefugeeDirectory;
import Business.Role.Role;
import Business.Role.SystemAdminRole;
import Business.UserAccount.UserAccountDirectory;
import java.util.ArrayList;

/**
 *
 * @author Rohan Jahagirdar, Bhanuja Nagore, Manish Patil
 */
public class UnitedNations extends Department {

    private static UnitedNations business;
    //private ArrayList<Continent> continentList;
    private  ContinentDirectory continentDirectory = new ContinentDirectory();
    private static RefugeeDirectory refugeeDirectory = new RefugeeDirectory();
    private static EmployeeDirectory employeeDirectory = new EmployeeDirectory();
    private static UserAccountDirectory userAccountDirectory = new UserAccountDirectory();
    
    private static UnitedNationsRefugeeRegistration unitedNationsRefugeeRegistration
            = new UnitedNationsRefugeeRegistration();
    
    public static UnitedNations getInstance() {
        if (business == null) {
            business = new UnitedNations();
        }
        return business;
    }

    private UnitedNations() {
        super(null);
      //  continentList = new ArrayList<>();
    }

    
    public ContinentDirectory getContinentDirectory() {
        return continentDirectory;
    }


    public Continent createAndAddContinent() {
        Continent continent = continentDirectory.addContinent();
        return continent;
    }
    
    public RefugeeDirectory getRefugeeDirectory() {
        return refugeeDirectory;
    }
    

    public static void setRefugeeDirectory(RefugeeDirectory refugeeDirectory) {
        UnitedNations.refugeeDirectory = refugeeDirectory;
    }
    
    public static void addRefugee(Refugee refugee) {
        refugeeDirectory.addRefugee(refugee);
    }
    
    
    public EmployeeDirectory getEmployeeDirectory() {
        return employeeDirectory;
    }

    public static Employee addEmployee(String name) {
        Employee employee = employeeDirectory.createEmployee(name);
        return employee;
    }
    
    public UnitedNationsRefugeeRegistration getRefugeeRegistration() {
        return unitedNationsRefugeeRegistration;
    }
    
    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roleList = new ArrayList<>();
        roleList.add(new SystemAdminRole());
        return roleList;
    }

    public boolean checkIfUsernameIsUnique(String username) {

        if (!this.getUserAccountDirectory().checkIfUsernameIsUnique(username)) {
            return false;
        }
        return true;
    }
}
