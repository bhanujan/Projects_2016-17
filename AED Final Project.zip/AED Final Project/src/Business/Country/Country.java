/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Country;

import Business.Department.Department;
import Business.Department.DepartmentDirectory;

/**
 *
 * @author 
 */
public abstract class Country extends Department{

    private CountryType countryType;
    private DepartmentDirectory departmentDirectory;
    
    public Country(String name, CountryType countryType) {
        super(name);
        this.countryType = countryType;
        departmentDirectory = new DepartmentDirectory();
    }
    
    public enum CountryType{
        RECEIVER("Receiver"),
        SENDER("Sender");
        
        
        private String value;

        private CountryType(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        @Override
        public String toString() {
            return value;
        }
    }

    public CountryType getCountryType() {
        return countryType;
    }
    
    
    public DepartmentDirectory addDepartmentDirectory() {
        return departmentDirectory;
    }

    public DepartmentDirectory getDepartmentDirectory() {
        return departmentDirectory;
    }
}
