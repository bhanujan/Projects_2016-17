/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Country;

import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author Rohan
 */
public class ReceiverCountry extends Country{

    public ReceiverCountry(String name) {
        super(name, CountryType.RECEIVER);
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        return null;
    }
}
