/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Country;

import java.util.ArrayList;

/**
 *
 * @author raunak
 */
public class CountryDirectory {
    
    private ArrayList<Country> countryList;

    public CountryDirectory() {
        countryList = new ArrayList<>();
    }

    public ArrayList<Country> getCountryList() {
        return countryList;
    }
    
    /*
    public Country createAndAddCountry(String name, Country.CountryType type){
        Country country = null;
        if (type == Country.CountryType.US){
            country = new USCountry(name);
            countryList.add(country);
        }
        return country;
    }
*/
    
    public Country createAndAddCountry(String name, Country.CountryType type){
        Country country = null;
        
        if (type == Country.CountryType.RECEIVER){
            country = new ReceiverCountry(name);
            countryList.add(country);
        }
        if (type == Country.CountryType.SENDER){
            country = new SenderCountry(name);
            countryList.add(country);
        }
        
        return country;
    }
    

}
