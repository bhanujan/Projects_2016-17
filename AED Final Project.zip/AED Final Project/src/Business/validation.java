/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author Manish Patil
 */
public class validation {
    
    private static final String STRING_PATTERN = "^[a-zA-Z]+$";
    
    
    /**
     * Validate the input variable to verify if its not empty and is a valid String. The check also verifies if the variable contains no integer.
     * @param variable Input parameter sent for validation
     * @return true if the variable is a valid String, false otherwise.
     */
    private static boolean validateString(String variable) {
        if(!variable.trim().isEmpty()) 
            return (variable.matches(STRING_PATTERN));
        else 
            return false;
    }
    
    /**
     * Validate the input string to verify if its not empty and is a valid Integer.
     * @param variable Input parameter sent for validation
     * @return true if the variable is a valid Integer, false otherwise.
     */
    private static boolean validateInteger(String variable) {
        if(!variable.trim().isEmpty()) {
            try{
                Integer.parseInt(variable);
                return true;
            } catch (NumberFormatException nfe){
                return false;
            }
        } else 
            return false;
    }   
}
